export interface Prompt {
  id: string;
  user_id: string;
  content: string;
  name: string;
  description?: string;
  created_at: string;
  updated_at: string;
} 