"use client";

export function ProcessingTimeChart() {
  return <div>Processing Time Chart</div>;
} 