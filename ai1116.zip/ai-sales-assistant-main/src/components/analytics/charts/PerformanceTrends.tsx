"use client";

export function PerformanceTrends() {
  return <div>Performance Trends</div>;
} 