"use client";

export function ErrorDistributionChart() {
  return <div>Error Distribution Chart</div>;
} 