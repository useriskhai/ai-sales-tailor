"use client";

export function SuccessRateChart() {
  return <div>Success Rate Chart</div>;
} 