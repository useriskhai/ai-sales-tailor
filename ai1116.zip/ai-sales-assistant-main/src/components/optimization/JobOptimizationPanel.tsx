"use client";

export function JobOptimizationPanel() {
  return <div>Job Optimization Panel</div>;
} 