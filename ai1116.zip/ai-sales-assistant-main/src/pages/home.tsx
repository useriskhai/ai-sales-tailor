import React from 'react';

const Home: React.FC = () => {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Homepage</h1>
    </div>
  );
};

export default Home;
