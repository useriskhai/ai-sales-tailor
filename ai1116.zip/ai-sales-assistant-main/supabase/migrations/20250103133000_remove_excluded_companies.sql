-- 除外企業テーブルの削除
DROP TABLE IF EXISTS excluded_companies; 