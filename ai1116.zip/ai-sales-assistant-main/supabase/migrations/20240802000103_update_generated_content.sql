ALTER TABLE generated_content
DROP COLUMN search_keyword,
ADD COLUMN subject TEXT;